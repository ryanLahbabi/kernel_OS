/* INF2610 - TP1
/ 2061606 : 
/ 2071348 : 
*/
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h> 
#include <stdbool.h>


struct Wheel {
    int id;
    bool isRearWheel;
};

struct Wing {
    int *id; 
};

struct Plane {
    char *id; 
    char planeType[10];
    bool isAvailable;
    struct Wheel *wheels; 
    struct Wing *wings;   
};

// Fonction pour créer des roues
    struct Wheel* createWheels(int initialId) {
    int numberOfWheels = 7;
    struct Wheel* wheels = malloc(numberOfWheels * sizeof(wheels));

    for (int i = 0; i < numberOfWheels; i++) {
        wheels[i].id = initialId + i;
        wheels[i].isRearWheel = (i >= 3);  // Les trois premières roues sont des roues avant, les autres sont des roues arrière
    }

    return wheels;
}



int main(int argc, char** argv) {
    printf("Hello\n");
    /* Remove comment once the code is completed for the given section to test */
    int id = 1;


    /* PARTIE 2 - [10 points] */

    /* Create wheel - [2 points] */
    struct Wheel* wheels = createWheels(id);

   for (int i = 0; i < 7; i++) {
        printf("Wheel %d: ID = %d, isRearWheel = %s\n", i + 1, wheels[i].id, wheels[i].isRearWheel ? "true" : "false");
    }


    /* Create wing - [4 points] */
    
    // long longId = 1;
    // Wing[] wings;
    // wings = createWings(longId);
    

    /* Create plane - [4 points] */
    /*
    int numberOfPlanes = 3;
    Plane* planes = malloc(sizeof(Plane) * numberOfPlanes);
    createPlanes(planes, *id, 3);
    */

    /* PARTIE 3 - [6 points] */

    /* Set availabilities - [1 point] */
    /*
    Plane plane = planes[0];
    setAvailability(plane, true);
    */

    /* Get available planes - [1 point] */
    /*
    getAvailablePlanes(planes, numberOfPlanes);
    */

    /* Classify planes - [2 points] */
    /*
    Plane plane = planes[1];
    setPlaneType(plane);
    */

    /* Return type specific planes - [2 points] */
    /*
    char planeType[] = "Small";
    getPlanesByType(planes, planeType,numberOfPlanes);
    */
}
